# Maxim Boost Pro — Android starter

Aplikasi pendamping untuk membaca notifikasi Android yang tersedia, menghitung tarif/km jika tarif dan jarak tercantum, serta menyimpan riwayat lokal.

## Membuka project
1. Ekstrak ZIP.
2. Buka folder `MaximBoostPro` di Android Studio.
3. Tunggu Gradle Sync, lalu jalankan ke HP Android (minimum Android 8 / API 26).

## Mengaktifkan
1. Buka aplikasi.
2. Tekan **Aktifkan akses pembaca notifikasi**, lalu aktifkan izin Maxim Boost Pro di pengaturan Android.
3. Tekan **Izinkan tampil di atas aplikasi lain** jika ingin tombol melayang.
4. Pastikan notifikasi Taxsee Driver aktif.

## Batasan prototipe
- Ini project sumber, bukan APK siap pasang; belum dikompilasi atau diuji pada perangkat/versi Taxsee tertentu.
- Pembacaan hanya dari notifikasi Android. Tidak membaca layar internal Taxsee, tidak mengakses server Maxim, dan tidak melakukan auto-accept.
- Nama paket dan format notifikasi dapat berbeda. Parser perlu disesuaikan dari contoh notifikasi nyata.
- Filter keuntungan lanjutan (biaya bensin, target tarif/km, dan skor order) merupakan tahap pengembangan berikutnya.
- Tombol melayang adalah label sederhana untuk uji izin overlay.
- Riwayat disimpan lokal di perangkat. Akses notifikasi dapat membuka konten notifikasi lain, jadi aktifkan hanya jika memahami izin ini.

## Parser kartu order Taxsee (tambahan)
`OrderParser.kt` berisi parser teks OCR untuk pola kartu penawaran yang terlihat pada contoh:
- tarif `Rp...`
- jarak `Sampai alamat`
- `Jarak perjalanan`
- `Platform fee`
- `Parking fee`
- status dan kategori layanan

Parser ini belum terhubung ke OCR/screen capture. Untuk membaca kartu yang tampil di layar secara langsung, tahap berikutnya memerlukan alur tangkapan layar Android yang dimulai dengan persetujuan pengguna dan OCR lokal. Tidak ada klik otomatis pada tombol Terima.
