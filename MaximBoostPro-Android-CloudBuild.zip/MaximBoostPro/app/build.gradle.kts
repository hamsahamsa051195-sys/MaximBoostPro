plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.maximboost.pro"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.maximboost.pro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
