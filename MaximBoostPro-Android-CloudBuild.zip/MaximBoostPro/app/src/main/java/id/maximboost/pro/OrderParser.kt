package id.maximboost.pro

/**
 * Parses visible Taxsee Driver order-card text.
 * Feed this parser text obtained from an explicitly user-authorized
 * screenshot/OCR workflow. It does not capture the screen by itself.
 */
data class ParsedOffer(
    val status: String?,
    val service: String?,
    val fare: Long?,
    val payment: String?,
    val pickupDistanceKm: Double?,
    val tripDistanceKm: Double?,
    val platformFee: Long?,
    val parkingFee: Long?,
    val pickup: String?,
    val destination: String?,
    val details: String?
) {
    val totalDistanceKm: Double?
        get() = if (pickupDistanceKm != null && tripDistanceKm != null)
            pickupDistanceKm + tripDistanceKm else null

    // Parking is shown separately because it may be reimbursed by the customer.
    fun netBeforeFuel(includeParkingAsDriverCost: Boolean): Long? {
        val f = fare ?: return null
        val platform = platformFee ?: 0L
        val parking = if (includeParkingAsDriverCost) parkingFee ?: 0L else 0L
        return f - platform - parking
    }

    fun farePerTripKm(): Double? =
        if (fare != null && tripDistanceKm != null && tripDistanceKm > 0)
            fare.toDouble() / tripDistanceKm else null

    fun farePerTotalKm(): Double? =
        if (fare != null && totalDistanceKm != null && totalDistanceKm > 0)
            fare.toDouble() / totalDistanceKm else null

    companion object {
        private fun amount(s: String): Long? =
            s.replace(".", "").replace(",", "").filter { it.isDigit() }.toLongOrNull()

        private fun distance(s: String): Double? =
            s.replace(",", ".").toDoubleOrNull()

        private fun firstAmount(text: String, pattern: Regex): Long? =
            pattern.find(text)?.groupValues?.getOrNull(1)?.let(::amount)

        fun parse(rawText: String): ParsedOffer {
            val text = rawText.replace('\u00a0', ' ')
            val fare = Regex("""(?i)\bRp\s*([0-9][0-9.,]*)""")
                .find(text)?.groupValues?.getOrNull(1)?.let(::amount)

            val pickup = Regex(
                """(?i)([0-9]+(?:[.,][0-9]+)?)\s*km\s*\.?\s*(?:sampai alamat|ke penjemputan)"""
            ).find(text)?.groupValues?.getOrNull(1)?.let(::distance)

            val trip = Regex(
                """(?i)([0-9]+(?:[.,][0-9]+)?)\s*km\s*\.?\s*(?:jarak perjalanan)"""
            ).find(text)?.groupValues?.getOrNull(1)?.let(::distance)

            val platform = firstAmount(
                text, Regex("""(?i)\bRp\s*([0-9][0-9.,]*)\s*Platform fee""")
            )
            val parking = firstAmount(
                text, Regex("""(?i)\bRp\s*([0-9][0-9.,]*)\s*Parking fee""")
            )

            val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
            val status = lines.firstOrNull {
                it.contains("Konfirmasi", true) ||
                it.contains("Telah berangkat", true)
            }
            val service = Regex("""(?i)\b(Bike|Food\s*&\s*Shop|Car|Delivery)\b""")
                .find(text)?.value
            val payment = when {
                text.contains("tunai", true) -> "Tunai"
                text.contains("cash", true) -> "Cash"
                else -> null
            }

            // Address extraction is intentionally conservative; OCR line breaks vary.
            val addressLines = lines.filter {
                it.contains("daerah", true) ||
                it.startsWith("Jalan ", true) ||
                it.startsWith("Lorong ", true) ||
                it.startsWith("Kos ", true) ||
                it.startsWith("Kedai ", true)
            }

            return ParsedOffer(
                status = status,
                service = service,
                fare = fare,
                payment = payment,
                pickupDistanceKm = pickup,
                tripDistanceKm = trip,
                platformFee = platform,
                parkingFee = parking,
                pickup = addressLines.getOrNull(0),
                destination = addressLines.getOrNull(1),
                details = lines.firstOrNull {
                    it.contains("mie ayam", true) ||
                    it.contains("bakso", true) ||
                    it.contains("pesanan", true)
                }
            )
        }
    }
}
