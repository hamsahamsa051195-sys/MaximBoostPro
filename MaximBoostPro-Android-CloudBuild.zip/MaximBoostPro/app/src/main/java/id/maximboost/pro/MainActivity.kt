package id.maximboost.pro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val green = Color.rgb(20, 145, 91)
    private val dark = Color.rgb(22, 29, 35)
    private val money = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark; window.navigationBarColor = dark
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 26, 22, 24); setBackgroundColor(Color.rgb(245, 247, 248)) }
        setContentView(ScrollView(this).apply { addView(content) })
        render()
    }
    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }
    private fun addText(parent: LinearLayout, value: String, size: Float, color: Int = dark, bold: Boolean = false) {
        parent.addView(TextView(this).apply { text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 8, 0, 8) })
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun render() {
        content.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,18); setBackgroundColor(dark) }
        addText(header, "MAXIM BOOST PRO", 23f, Color.WHITE, true)
        addText(header, "Asisten order untuk Taxsee Driver", 14f, Color.LTGRAY); content.addView(header)
        addText(content, "DASHBOARD", 13f, green, true)
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,12,16,12); setBackgroundColor(Color.WHITE) }
        addText(card, "ORDER TERBARU", 13f, green, true)
        val latest = OrderStore.latest(this)
        if (latest == null) {
            addText(card, "Belum ada notifikasi order terbaca.", 16f)
            addText(card, "Aktifkan akses notifikasi Taxsee Driver untuk mulai membaca.", 13f, Color.DKGRAY)
        } else {
            addText(card, latest.title.ifBlank { "Notifikasi order" }, 18f, dark, true)
            addText(card, latest.body, 14f)
            addText(card, "Tarif: ${latest.fare?.let { money.format(it) } ?: "belum terbaca"}", 15f, dark, true)
            addText(card, "Jarak: ${latest.distanceKm?.let { "$it km" } ?: "belum terbaca"}", 14f)
            val rate = if (latest.fare != null && latest.distanceKm != null && latest.distanceKm > 0) latest.fare / latest.distanceKm else null
            addText(card, "Tarif/km: ${rate?.let { money.format(it) } ?: "belum dapat dihitung"}", 14f, green, true)
            addText(card, "Diterima: " + SimpleDateFormat("dd MMM, HH:mm:ss", Locale("id", "ID")).format(Date(latest.receivedAt)), 12f, Color.GRAY)
        }
        content.addView(card)
        addText(content, "PENGATURAN & AKSES", 13f, green, true)
        content.addView(button("1. Aktifkan akses pembaca notifikasi") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) })
        content.addView(button("2. Izinkan tampil di atas aplikasi lain") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        content.addView(button("Tampilkan tombol melayang") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingService::class.java))
                Toast.makeText(this, "Tombol melayang dijalankan.", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "Izinkan akses overlay terlebih dahulu.", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("Hentikan tombol melayang") { stopService(Intent(this, FloatingService::class.java)) })
        content.addView(button("Muat ulang data order") { render() })
        addText(content, "RIWAYAT ORDER (maks. 100)", 13f, green, true)
        OrderStore.history(this).take(20).forEachIndexed { i, o ->
            addText(content, "${i + 1}. ${o.title.ifBlank { o.body.take(55) }} — ${o.fare?.let { money.format(it) } ?: "tarif belum terbaca"}", 13f, dark)
        }
        addText(content, "Catatan: pembacaan bergantung pada isi notifikasi Taxsee Driver. Jika tarif/jarak tidak ada di notifikasi, aplikasi tidak bisa menebaknya. Periksa detail order di Taxsee sebelum menerima.", 12f, Color.DKGRAY)
    }
}
