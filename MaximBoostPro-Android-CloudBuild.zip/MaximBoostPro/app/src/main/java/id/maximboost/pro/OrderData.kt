package id.maximboost.pro

import android.content.Context
import org.json.JSONObject

data class OrderInfo(val title: String, val body: String, val fare: Long?, val distanceKm: Double?, val receivedAt: Long, val sourcePackage: String) {
    fun toJson() = JSONObject().apply {
        put("title", title); put("body", body); put("fare", fare ?: JSONObject.NULL)
        put("distance", distanceKm ?: JSONObject.NULL); put("time", receivedAt); put("pkg", sourcePackage)
    }
    companion object {
        fun fromJson(j: JSONObject) = OrderInfo(j.optString("title"), j.optString("body"),
            if (j.isNull("fare")) null else j.optLong("fare"),
            if (j.isNull("distance")) null else j.optDouble("distance"),
            j.optLong("time"), j.optString("pkg"))
    }
}
object OrderStore {
    private const val PREF = "maxim_boost_store"
    fun save(context: Context, order: OrderInfo) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = org.json.JSONArray(p.getString("history", "[]"))
        arr.put(order.toJson()); while (arr.length() > 100) arr.remove(0)
        p.edit().putString("latest", order.toJson().toString()).putString("history", arr.toString()).apply()
    }
    fun latest(context: Context): OrderInfo? = runCatching {
        val s = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("latest", null) ?: return null
        OrderInfo.fromJson(JSONObject(s))
    }.getOrNull()
    fun history(context: Context): List<OrderInfo> = runCatching {
        val a = org.json.JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("history", "[]"))
        (0 until a.length()).map { OrderInfo.fromJson(a.getJSONObject(it)) }.reversed()
    }.getOrDefault(emptyList())
}
