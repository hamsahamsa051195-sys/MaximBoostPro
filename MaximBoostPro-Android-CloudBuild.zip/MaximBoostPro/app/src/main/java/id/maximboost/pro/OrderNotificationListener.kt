package id.maximboost.pro

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class OrderNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val combined = listOf(title, body, big).filter { it.isNotBlank() }.distinct().joinToString(" · ")
        val pkg = sbn.packageName.lowercase(Locale.ROOT)
        val text = combined.lowercase(Locale.ROOT)
        val likelySource = pkg.contains("taxsee") || pkg.contains("maxim")
        val keywords = listOf("order", "pesanan", "perjalanan", "jemput", "tarif", "rp", "idr")
        if (!likelySource && keywords.none { text.contains(it) }) return
        if (combined.isBlank()) return

        val fareText = Regex("(?:rp\\s*)?([0-9][0-9.,]{3,})\\s*(?:rp|idr)?", RegexOption.IGNORE_CASE)
            .find(combined)?.groupValues?.get(1)
        val fare = fareText?.replace(".", "")?.replace(",", "")?.toLongOrNull()
        val distance = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*km", RegexOption.IGNORE_CASE)
            .find(combined)?.groupValues?.get(1)?.replace(",", ".")?.toDoubleOrNull()
        OrderStore.save(this, OrderInfo(title, combined, fare, distance, System.currentTimeMillis(), sbn.packageName))
    }
}
