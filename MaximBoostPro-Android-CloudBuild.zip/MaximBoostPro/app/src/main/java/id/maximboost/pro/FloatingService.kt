package id.maximboost.pro

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color

class FloatingService : Service() {
    private var view: TextView? = null
    private var wm: WindowManager? = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 180 }
        view = TextView(this).apply {
            text = "MBP"; textSize = 14f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(22, 130, 85))
            setPadding(24, 18, 24, 18); elevation = 12f
        }
        runCatching { wm?.addView(view, lp) }
    }
    override fun onDestroy() { runCatching { view?.let { wm?.removeView(it) } }; view = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
